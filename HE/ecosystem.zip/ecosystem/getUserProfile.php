<?php

require_once('db.php');
require_once('prepareStatements.php');

$res = array();

//select * from content where processed_relations=0
$q1 = "SELECT * FROM " . $prefix . "users WHERE nick='" . $_REQUEST["n"] . "' LIMIT 0,1";
$r1 = $dbh->query($q1);
if($r1){
	foreach ( $r1 as $row1) {
		
		$res["user"] = $row1;
	}
}


$relations = array();

$q2 = "SELECT r.nick1 as n1, r.nick2 as n2, r.c as c, u1.image_url as i1, u2.image_url as i2 FROM relations r, users u1, users u2 WHERE (r.nick1='"  . $_REQUEST["n"] . "' OR r.nick2='"  . $_REQUEST["n"] . "') AND u1.nick=r.nick1 AND u2.nick=r.nick2 LIMIT 0,50";
$r2 = $dbh->query($q2);
if($r1){
	foreach ( $r2 as $row2) {
		$relations[] = $row2;
	}
}

$res["relations"] = $relations;

echo( json_encode($res) );

?>